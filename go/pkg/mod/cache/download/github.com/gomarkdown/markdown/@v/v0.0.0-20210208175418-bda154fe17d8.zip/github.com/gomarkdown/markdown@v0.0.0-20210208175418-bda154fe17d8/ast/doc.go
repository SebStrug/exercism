/*
Package ast defines tree representation of a parsed markdown document.
*/
package ast
