1. Download and install [Xamarin Studio Community][1].

Lost

In space.

  [1]: https://store.xamarin.com/
  [2]: http://i.stack.imgur.com/hHjMM.png
