# Markdown to HTML cmd-line tool

If you have Go installed, install with:

    go get -u github.com/gomarkdown/mdtohtml

To run:

    mdtohtml [options] inputfile [outputfile]

Run `mdtohtml` to see all options.

This is also an example of how to use [gomarkdown/markdown](https://github.com/gomarkdown/markdown) library.
